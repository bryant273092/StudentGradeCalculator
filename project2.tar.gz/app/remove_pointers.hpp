#include"output.hpp"
void remove_pointers(Artifacts* graded_artifacts,Students* students,Cutpoints* cutpoints);