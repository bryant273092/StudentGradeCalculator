#include<iostream>
#include "input.hpp"

void calculate_total_scores(Artifacts* artifacts, Students* students);