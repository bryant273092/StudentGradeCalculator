#include "calculate_total_scores.hpp"
void print_total_scores(Students* students);
void print_cutpoint(Students* students, Cutpoints* cutpoints, int count);